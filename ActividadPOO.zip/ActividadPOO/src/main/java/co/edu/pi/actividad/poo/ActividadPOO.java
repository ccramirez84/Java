
package co.edu.pi.actividad.poo;

/**
 *
 * @author cmont
 */
public class ActividadPOO {
    public static void main(String[] args) {
        Electrodomestico[] electrodomesticos = new Electrodomestico[10];

        electrodomesticos[0] = new Electrodomestico(200, 10, 'C', "rojo");
        electrodomesticos[1] = new Lavadora(300, 60, 'B', "blanco", 40);
        electrodomesticos[2] = new Television(500, 5, 'A', "negro", 50, true);
        electrodomesticos[3] = new Electrodomestico(150, 25, 'D', "gris");
        electrodomesticos[4] = new Lavadora(250, 30, 'E', "azul", 25);
        electrodomesticos[5] = new Television(400, 8, 'F', "blanco", 32, false);
        electrodomesticos[6] = new Electrodomestico(100, 15);
        electrodomesticos[7] = new Lavadora(350, 55, 'A', "rojo", 35);
        electrodomesticos[8] = new Television(600, 12, 'B', "negro", 60, true);
        electrodomesticos[9] = new Electrodomestico(180, 20, 'C', "azul");

        double totalElectrodomesticos = 0;
        double totalLavadoras = 0;
        double totalTelevisiones = 0;

        for (Electrodomestico electrodomestico : electrodomesticos) {
            double precioFinal = electrodomestico.precioFinal();
            totalElectrodomesticos += precioFinal;

            if (electrodomestico instanceof Lavadora) {
                totalLavadoras += precioFinal;
            } else if (electrodomestico instanceof Television) {
                totalTelevisiones += precioFinal;
            }
        }

        System.out.println("Total Electrodomésticos: $" + totalElectrodomesticos);
        System.out.println("Total Lavadoras: $" + totalLavadoras);
        System.out.println("Total Televisiones: $" + totalTelevisiones);
    }
}