
package co.edu.pi.actividad.poo;

/**
 *
 * @author cmont
 */
public class Television extends Electrodomestico {
    private int resolucion;
    private boolean sintonizadorTDT;

    private final static int RESOLUCION_DEFECTO = 20;
    private final static boolean SINTONIZADOR_TDT_DEFECTO = false;

    public Television() {
        this(PRECIO_BASE_DEFECTO, PESO_DEFECTO, CONSUMO_DEFECTO, COLOR_DEFECTO, RESOLUCION_DEFECTO, SINTONIZADOR_TDT_DEFECTO);
    }

    public Television(double precioBase, double peso) {
        this(precioBase, peso, CONSUMO_DEFECTO, COLOR_DEFECTO, RESOLUCION_DEFECTO, SINTONIZADOR_TDT_DEFECTO);
    }

    public Television(double precioBase, double peso, char consumoEnergetico, String color, int resolucion, boolean sintonizadorTDT) {
        super(precioBase, peso, consumoEnergetico, color);
        this.resolucion = resolucion;
        this.sintonizadorTDT = sintonizadorTDT;
    }

    public int getResolucion() {
        return resolucion;
    }

    public boolean isSintonizadorTDT() {
        return sintonizadorTDT;
    }

    @Override
    public double precioFinal() {
        double precioFinal = super.precioFinal();
        if (resolucion > 40) {
            precioFinal *= 1.3;
        }
        if (sintonizadorTDT) {
            precioFinal += 50;
        }
        return precioFinal;
    }
}