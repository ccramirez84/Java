
package co.edu.pi.actividad.poo;

/**
 *
 * @author cmont
 */
public class Electrodomestico {
    protected double precioBase;
    protected String color;
    protected char consumoEnergetico;
    protected double peso;

    protected final static String COLOR_DEFECTO = "blanco";
    protected final static char CONSUMO_DEFECTO = 'F';
    protected final static double PRECIO_BASE_DEFECTO = 100;
    protected final static double PESO_DEFECTO = 5;

    public Electrodomestico() {
        this(PRECIO_BASE_DEFECTO, PESO_DEFECTO, CONSUMO_DEFECTO, COLOR_DEFECTO);
    }

    public Electrodomestico(double precioBase, double peso) {
        this(precioBase, peso, CONSUMO_DEFECTO, COLOR_DEFECTO);
    }

    public Electrodomestico(double precioBase, double peso, char consumoEnergetico, String color) {
        this.precioBase = precioBase;
        this.peso = peso;
        comprobarConsumoEnergetico(consumoEnergetico);
        comprobarColor(color);
    }

    public double getPrecioBase() {
        return precioBase;
    }

    public String getColor() {
        return color;
    }

    public char getConsumoEnergetico() {
        return consumoEnergetico;
    }

    public double getPeso() {
        return peso;
    }

    private void comprobarConsumoEnergetico(char letra) {
        if (letra >= 'A' && letra <= 'F') {
            this.consumoEnergetico = letra;
        } else {
            this.consumoEnergetico = CONSUMO_DEFECTO;
        }
    }

    private void comprobarColor(String color) {
        String[] colores = {"blanco", "negro", "rojo", "azul", "gris"};
        for (String c : colores) {
            if (c.equalsIgnoreCase(color)) {
                this.color = c;
                return;
            }
        }
        this.color = COLOR_DEFECTO;
    }

    public double precioFinal() {
        double precioAdicional = 0;
        switch (consumoEnergetico) {
            case 'A':
                precioAdicional += 100;
                break;
            case 'B':
                precioAdicional += 80;
                break;
            case 'C':
                precioAdicional += 60;
                break;
            case 'D':
                precioAdicional += 50;
                break;
            case 'E':
                precioAdicional += 30;
                break;
            case 'F':
                precioAdicional += 10;
                break;
        }
        if (peso >= 0 && peso <= 19) {
            precioAdicional += 10;
        } else if (peso >= 20 && peso <= 49) {
            precioAdicional += 50;
        } else if (peso >= 50 && peso <= 79) {
            precioAdicional += 80;
        } else if (peso >= 80) {
            precioAdicional += 100;
        }
        return precioBase + precioAdicional;
    }
}