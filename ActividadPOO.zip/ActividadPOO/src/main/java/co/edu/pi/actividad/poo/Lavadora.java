
package co.edu.pi.actividad.poo;

/**
 *
 * @author cmont
 */
public class Lavadora extends Electrodomestico {
    private int carga;

    private final static int CARGA_DEFECTO = 5;

    public Lavadora() {
        this(PRECIO_BASE_DEFECTO, PESO_DEFECTO, CONSUMO_DEFECTO, COLOR_DEFECTO, CARGA_DEFECTO);
    }

    public Lavadora(double precioBase, double peso) {
        this(precioBase, peso, CONSUMO_DEFECTO, COLOR_DEFECTO, CARGA_DEFECTO);
    }

    public Lavadora(double precioBase, double peso, char consumoEnergetico, String color, int carga) {
        super(precioBase, peso, consumoEnergetico, color);
        this.carga = carga;
    }

    public int getCarga() {
        return carga;
    }

    @Override
    public double precioFinal() {
        double precioFinal = super.precioFinal();
        if (carga > 30) {
            precioFinal += 50;
        }
        return precioFinal;
    }
}